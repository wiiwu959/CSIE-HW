#pragma once
#include"Creatures.h"
//=========================================================
// Cyberdemon
//=========================================================
class Cyberdemon : public Creature
{
private:
	string getSpecies();

public:
	Cyberdemon();
	Cyberdemon(int newStrength, int newHit);
	int getDamage();
	int getDamage(string species);
};
