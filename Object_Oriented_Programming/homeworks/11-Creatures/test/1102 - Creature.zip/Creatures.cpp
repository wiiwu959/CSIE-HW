#include "Creatures.h"

//=========================================================
// Creature
//=========================================================
Creature::Creature()
	:strength(10), hitpoints(10)
{ }

Creature::Creature(int newStrength, int newHit)
	: strength(newStrength), hitpoints(newHit)
{ }

int Creature::getDamage()
{
	int damage;
	damage = (rand() % getStrengh()) + 1;
	return damage;
}

void Creature::setStrengh(int newStr)
{
	strength = newStr;
}

void Creature::setHp(int newHp)
{
	hitpoints = newHp;
}

int Creature::getStrengh() const
{
	return strength;
}

int Creature::getHp() const
{
	return hitpoints;
}
