#pragma once
#include"Cyberdemon.h"
//=========================================================
// Balrog
//=========================================================
class Balrog : public Cyberdemon
{
private:
	string getSpecies();

public:
	Balrog();
	Balrog(int newStrength, int newHit);
	int getDamage();
};
