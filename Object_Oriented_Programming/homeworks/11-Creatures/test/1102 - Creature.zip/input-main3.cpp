#include "Creatures.h"

int main()
{
	srand(static_cast<int>(time(NULL)));
	Human h(40,20);
	h.getDamage();
	cout << endl;

	Elf e(5,10);
	e.getDamage();
	cout << endl;

	Balrog b;
	b.getDamage();
	cout << endl;

	Cyberdemon c(10,10);
	c.getDamage();
	cout << endl;

	return 0;
}