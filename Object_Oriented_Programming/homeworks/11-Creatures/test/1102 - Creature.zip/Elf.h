#pragma once
#include"Creatures.h"
class Elf : public Creature
{
private:
	string getSpecies();

public:
	Elf();
	Elf(int newStrength, int newHit);
	int getDamage();
};
