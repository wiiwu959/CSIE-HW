#include"Cyberdemon.h"
string Cyberdemon::getSpecies()
{
	return string("Cyberdemon");
}

Cyberdemon::Cyberdemon()
	:Creature()
{ }

Cyberdemon::Cyberdemon(int newStrength, int newHit)
	: Creature(newStrength, newHit)
{ }

int Cyberdemon::getDamage()
{
	return getDamage(getSpecies());
}

int Cyberdemon::getDamage(string species)
{
	int damage;
	damage = Creature::getDamage();
	cout << species << " attacks for " <<
		damage << " points!" << endl;

	if ((rand() % 100) < 5)
	{
		damage = damage + 50;
		cout << "Demonic attack inflicts 50"
			<< " additional damage points!" << endl;
	}

	return damage;
}
