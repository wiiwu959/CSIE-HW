#include"Balrog.h"
string Balrog::getSpecies()
{
	return string("Balrog");
}

Balrog::Balrog()
	:Cyberdemon()
{ }

Balrog::Balrog(int newStrength, int newHit)
	: Cyberdemon(newStrength, newHit)
{ }

int Balrog::getDamage()
{
	int damage;
	damage = Cyberdemon::getDamage(getSpecies());

	int damage2 = Creature::getDamage();
	cout << "Balrog speed attack inflicts "
		<< damage2 << " additional damage points!" << endl;
	damage = damage + damage2;

	return damage;
}
