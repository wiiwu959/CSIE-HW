#include "Creatures.h"

int main()
{
	srand(static_cast<int>(time(NULL)));
	Human h;
	h.getDamage();
	cout << endl;

	Elf e(30,20);
	e.getDamage();
	cout << endl;

	Balrog b;
	b.getDamage();
	cout << endl;

	Cyberdemon c(20, 40);
	c.getDamage();
	cout << endl;

	return 0;
}