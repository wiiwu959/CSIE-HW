#pragma once
#include"Creatures.h"
//=========================================================
// Human
//=========================================================
class Human : public Creature
{
private:
	string getSpecies();

public:
	Human();
	Human(int newStrength, int newHit);
	int getDamage();
};
