#include"Human.h"
//=========================================================
// Human
//=========================================================
string Human::getSpecies()
{
	return string("Human");
}

Human::Human()
	:Creature()
{ }

Human::Human(int newStrength, int newHit)
	: Creature(newStrength, newHit)
{ }

int Human::getDamage()
{
	int damage;
	damage = Creature::getDamage();

	cout << getSpecies() << " attacks for " <<
		damage << " points!" << endl;

	return damage;
}
