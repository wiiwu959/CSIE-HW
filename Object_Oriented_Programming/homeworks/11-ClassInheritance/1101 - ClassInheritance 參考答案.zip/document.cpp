#include "document.h"

// ======================
// Assignment operator
// simply copy the string for the text.
// ======================
Document& Document::operator =(const Document& rightSide)
{
	// Simply copy the string for the text value
	this->text = rightSide.text;
	return *this;
}

// ======================
// ContainsKeyword
// Returns true if the Document
// object passed in contains keyword as a substring
// of its text property.
// ======================
bool ContainsKeyword(const Document& docObject, string keyword)
{
	if (docObject.getText().find(keyword) != string::npos) return true;
	return false;
}