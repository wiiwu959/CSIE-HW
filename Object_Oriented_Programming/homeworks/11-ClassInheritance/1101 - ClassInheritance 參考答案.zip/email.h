#ifndef EMAIL_H
#define EMAIL_H

#include "document.h"

// Define class for Email, derive from Document
// For brevity, short one-line methods are defined here in the
// header.

class Email : public Document
{
public:
	Email() : Document()
	{
	}
	Email(string body, string sender, string recipient, string title) :
		Document(body), sender(sender), recipient(recipient),
		title(title)
	{
	}
	void setRecipient(string s)
	{
		recipient = s;
	}
	string getRecipient()
	{
		return recipient;
	}
	void setSender(string s)
	{
		sender = s;
	}
	string getSender()
	{
		return sender;
	}
	void setTitle(string s)
	{
		title = s;
	}
	string getTitle()
	{
		return title;
	}
	Email& operator =(const Email& rightSide);
private:
	string sender, recipient, title;
};

#endif // !EMAIL_H