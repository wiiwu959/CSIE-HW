#include "document.h"
#include "email.h"
#include "file.h"

// ======================
//     main function
// ======================
int main()
{
	// Create several test objects

	Document doc1("doc1");

	Email email1("text1 for email", "sender1", "recipient1", "title1");
	Email email2("text2 for email", "sender2", "recipient2", "title2");

	File file1("text1 for file", "pathname1");
	File file2("text1 for file", "pathname2");

	cout << "doc1 " << doc1.getText() << endl;
	cout << "email1 " << email1.getText() << " - " << email1.getSender() << " - " << email1.getRecipient() << " - " << email1.getTitle() << endl;
	cout << "email2 " << email2.getText() << " - " << email2.getSender() << " - " << email2.getRecipient() << " - " << email2.getTitle() << endl;
	cout << "file1 " << file1.getText() << " - " << file1.getPathname() << endl;
	cout << "file2 " << file2.getText() << " - " << file2.getPathname() << endl;

	cout << endl << "operator '=' testing" << endl;

	doc1 = email1;

	cout << "doc1 " << doc1.getText() << endl;

	doc1 = file1;

	cout << "doc1 " << doc1.getText() << endl;

	email2 = email1;

	cout << "email2 " << email2.getText() << " - " << email2.getSender() << " - " << email2.getRecipient() << " - " << email2.getTitle() << endl;

	system("pause");
	
	return 0;
}

