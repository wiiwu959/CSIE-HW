#include "document.h"
#include "email.h"
#include "file.h"

// ======================
//     main function
// ======================
int main()
{
	// Create several test objects
	Email test1("text1 for email", "sender", "recipient", "title");

	File test2("text2 for file", "pathname");

	if(ContainsKeyword(test1, "text")) cout << "test1 contains text" << endl;
	if (ContainsKeyword(test2, "text")) cout << "test2 contains text" << endl;

	if (ContainsKeyword(test1, "file")) cout << "???" << endl;
	if (ContainsKeyword(test2, "email")) cout << "???" << endl;

	cout << test1.getText() << " - " << test1.getSender() << " - " << test1.getRecipient() << " - " << test1.getTitle() << endl;
	cout << test2.getText() << " - " << test2.getPathname() << endl;

	system("pause");
	
	return 0;
}

